# me.haroleethan.BreezeThrowbackDark
The mix Between Breeze and a Throwback to Oxygen in Dark theme

Credits to KDE for the Breeze theme, including the icons and splash screen.

# Installation
Move this folder (me.haroleethan.BreezeThrowbackDark) into /home/$USER/.local/share/plasma/look-and-feel (create the directory for look-and-feel if you don't see it)

or if you want it system-wide, place it in /usr/share/plasma/look-and-feel
